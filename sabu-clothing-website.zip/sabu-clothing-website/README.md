# Sabu Clothing website

A responsive one-page website based on the supplied Sabu Clothing design.

## Files
- `index.html` — page content and structure
- `style.css` — layout, colours, typography and responsive styles
- `script.js` — mobile navigation and automatic copyright year

## Preview on your computer
1. Download and unzip the project.
2. Open the `index.html` file in a web browser.

No build tools or installation are required.

## Publish with GitHub Pages
1. Sign in to GitHub and create a new repository, for example `sabu-clothing`.
2. Upload **all three website files** (`index.html`, `style.css`, and `script.js`) to the top level of the repository.
3. Open the repository's **Settings** tab.
4. Select **Pages** from the left-hand menu.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select branch `main` and folder `/ (root)`, then click **Save**.
7. Wait a few minutes. GitHub will show your published website URL in the Pages section.

## Before publishing
- Replace `hello@sabuclothing.com` in `index.html` with your real business email address.
- Replace the sample clothing photos with your own product photos if you have them.
- Update the text, product descriptions and contact details to match your business.

## Images and fonts
The sample photos are loaded from Unsplash and the fonts are loaded from Google Fonts. An internet connection is needed for those external assets to appear. The website itself is hosted by GitHub Pages.
